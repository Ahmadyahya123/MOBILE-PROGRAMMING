package com.example.prak1mp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.security.MessageDigest

class MainActivity : AppCompatActivity() {

    private lateinit var databaseDBHelper: DBHelper

    fun getMD5Hash(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        val bytes = md.digest(input.toByteArray())
// Konversi ke Hexa
        val hexString = StringBuilder()
        for (i in bytes.indices) {
            val hex = Integer.toHexString(0xFF and bytes[i].toInt())
            if (hex.length == 1) {
                hexString.append('0')
            }
            hexString.append(hex)
        }
        return hexString.toString()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inisialisasi Objek Activity
        var inputNIM = findViewById<EditText>(R.id.inputNIM)
        var inputPassword = findViewById<EditText>(R.id.inputPassword)
        val btnMasuk = findViewById<Button>(R.id.btnMasuk)
        val btnDaftar = findViewById<Button>(R.id.btnDaftar)
        val btnTutup = findViewById<Button>(R.id.btnTutup)

        databaseDBHelper = DBHelper(this)

        btnMasuk.setOnClickListener{
            val dataNIM:String = inputNIM.text.toString()
            val dataPassword:String = inputPassword.text.toString()
            // Ubah Password ke MD5
            val hashedPassword = getMD5Hash(dataPassword)
            // Buat Kueri
            val query = "SELECT * FROM TBL_MHS WHERE nim = '"+dataNIM+"' " +
                    "AND password = '"+hashedPassword+"'"
            // Buka Akses DB
            val db = databaseDBHelper.readableDatabase
            val cursor = db.rawQuery(query, null)
            // Cek Hasil Kueri
            val result = cursor.moveToFirst()
            if(result == true)
            {
            // Login Benar-> ambil data
                val dataName = cursor.getString(cursor.getColumnIndexOrThrow("nama"))
                val dataEmail = cursor.getString(cursor.getColumnIndexOrThrow("email"))
                // kirimkan data via intent
                var intent:Intent = Intent(this,ProfileMahasiswa::class.java)
                intent.putExtra("nim",dataNIM)
                intent.putExtra("nama",dataName)
                intent.putExtra("email",dataEmail)
                startActivity(intent)

            }
            else {
                // Login Salah -> Bersihkan Semua
                Toast.makeText(
                    applicationContext, "Data Login Salah",
                    Toast.LENGTH_SHORT
                ).show()
                inputNIM.setText("")
                inputPassword.setText("")
            }


        }
        btnDaftar.setOnClickListener{
            //buat variabel inten
            val  intent:Intent = Intent(this, DaftarMahasiswa::class.java)
            // jalankan Intent
            startActivity(intent)
        }
        btnTutup.setOnClickListener {
            //perintah activity untuk selesai
            finish()
        }
    }
}